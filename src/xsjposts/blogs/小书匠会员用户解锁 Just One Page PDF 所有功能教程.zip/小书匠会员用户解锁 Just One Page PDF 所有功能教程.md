---
title: 小书匠会员用户解锁 Just One Page PDF 所有功能教程
tags: 文档,小书匠,JOPP,插件,pdf
createDate: 2024-10-21
slug: /chrome/just_one_page_pdf_integration
cover: '![](./images/randomCover.jpg)'
---


[toc!]

# 什么是 Just One Page PDF

**Just One Page PDF**(简称 **JOPP**), 是一款可以将网页快速保存成 PDF 的浏览器插件，支持类似网页截图插件，但强大的是，该插件保存的 PDF 是矢量格式，支持文字选择，文字/矢量图片无限放大等特性．特别适合有文章剪藏保存需求的用户，高度还原网页样式．

## 主要功能

1. 支持将网页保存成一整页 PDF
2. 支持将网页保存成多种预定义长宽的 PDF
3. 支持选择网页特定区域保存成 PDF
4. 支持选择网页特定 HTML 结点保存成 PDF
5. 支持批量保存网页为 PDF
6. 支持自动提取网页内的正文保存成 PDF (Article Print)
    1. 支持使用 css 自定义页眉页脚
    2. 支持生成目录，同时支持 css 调整目录样式
    3. 支持通过 css 自定义想要的字体
7. 支持将生成的 PDF 保存到 Dropbox, OneDrive, GoogleDrive 等多种第三方平台
8. 支持将生成的 PDF 发送到指定的邮箱（比如 kindle, onenote,evernote 等邮箱服务）
9. 支持对生成的 PDF 进行历史管理

## JOPP 教程

目前只提供了[视频教程](https://www.youtube.com/watch?v=BbHTAUUXHHs)．

## 使用 JOPP 时，需要注意什么

1. 能够正常访问 colorink.top , google fonts, github pages 等服务器资源

虽然使用 JOPP 插件进行 HTML 打印 PDF,都是在本地执行，系统没有将用户要打印的 html,图片等资源提交到 JOPP 服务器上，但因为有些 js 代码，需要先从 JOPP 等服务器上下载下来，所以需要用户保证自己的电脑能连接到 JOPP 需要的服务器上，比如 google 的字体服务器， github 的 pages 服务器等．

# 如何使用小书匠会员解锁 JOPP 功能

目前 JOPP 的用户体系与小书匠的用户体系是分开独立的． JOPP 的用户无法在小书匠上登录使用，但小书匠的用户可以通过下面的方法，使用 JOPP 的所有功能（free, VIP1, VIP2）．跟 JOPP 的永久会员不同的是，小书匠用户有会员到期限制．非小书匠会员，或者小书匠会员到期， JOPP 将自动取消 VIP2 权限．

解锁步骤

1. 访问小书匠网页版 https://markdown.xiaoshujiang.com
2. 点击`小书匠主按钮>用户`
3. 使用小书匠帐号登录
4. 确保小书匠用户为会员用户（不包括临时会员）
5. 鼠标右键，打开浏览器上下文菜单，找到 `Just One Page PDF`, 点击 `使用小书匠帐号认证` 项．
6. 认证成功后，就可以使用 JOPP 的所有功能了

![](./images/1729500794210.png)

![](./images/1729501251940.png)

# 疑问

## 小书匠会员到期后，还能正常使用 JOPP 吗

小书匠的会员到期后， JOPP 这边会自动取消所有 VIP2 相关的权限．同时需要注意，小书匠的临时会员是无法解锁 JOPP 功能．

## JOPP 的用户能在小书匠系统里登录吗

JOPP 与小书匠是两套完全不同的系统，所以 JOPP 的用户是无法在小书匠上登录使用的．但 JOPP 这边为小书匠用户提供了一项福利，就是小书匠的会员用户，是可以解锁所有 JOPP 的功能的．

