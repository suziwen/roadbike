---
title: 搭建 pouchdb-server 数据库，实现小书匠下自己的远程数据中心
tags: 教程,数据中心,pouchdb,pouchdb-server,小书匠
createDate: 2021-12-16
slug: /database/setup_custom_pouchdb_server
cover: '![](./images/monitor-1307227_1280.jpg)'
---


[toc!]

# 概述

本文介绍另一种搭建用于小书匠数据中心的数据库，[PouchDB Server](https://github.com/pouchdb/pouchdb-server)。该数据库实现了 CouchDB 的大部份协议，同时添加了多种存储方案，比如 LevelDB 存储格式(默认)，SQLite 存储格式及内存保存（应用重启就自动清空，用于测试场景比较多）。

# 要求

## 操作系统

只要能安装 nodejs 11 以上版本的操作系统都可以，也就是说 Window, Linux, Mac等主流操作系统都支持。


# 操作步骤

``` 
npm install -g pouchdb-server
pouchdb-server -p 3020
```

然后访问 `http://localhost:3020/_utils`

如果访问成功，就表示安装完成。

接下来，就可以直接在小书匠上配置数据中心的同步参数了。

# 小书匠编辑器自定义数据中心配置步骤

该流程可以参考 [2018-3-7 使用小书匠 markdown 编辑器的数据中心功能，配合自己云服务器上的 CouchDB 数据库，实现自己的文件数据中心](/setup_custom_couchdb_server#小书匠编辑器自定义数据中心配置步骤) 这篇文章.

主要的输入项就是 `数据库地址`, 直接输入下面的内容就可以了。

``` 
http://localhost:3020/test
```

格式就是

``` 
http://localhost:3020/{数据库名}
```


![](./images/1639641449530.png)


注: 数据库名不能以下划线开头，建议只使用数字字母组合。

# PouchDB Server 高级配置

对于想更个性化的配置自己的 PouchDB Server,或者更好的集合进自己的服务里，可以参考 PouchDB Server 的[官方文档](https://github.com/pouchdb/pouchdb-server)

