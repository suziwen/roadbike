---
title: 如何使用小书匠阅读网络 pdf 文件，并进行批注操作
tags: 小书匠,pdf,批注,阅读,文档,引用
createDate: 2023-02-28
grammar_attachment: true
slug: 'pdf/pdfviewer_web_pdf'
emoji: 📚️
cover: '![](./images/randomCover.jpg)'
---


[toc!]


小书匠早先版本，已经支持了 pdf 阅读批注功能，具体可以看这篇文章：[PDF 阅读，批注，引用使用](pdf/pdfviewer_highlights_reference)。不过，该方式需要手动将 pdf 文件下载下来，并交给小书匠进行管理，操作上有些繁琐，同时，也有附件不能超过 30M 大小的限制问题。

为了解决上面的问题，小书匠从 `8.11.17` 版本开始，支持阅读网络上的 pdf 文件，并进行批注高亮等操作。用户可以直接在图片语法里，使用网络链接的 pdf，当需要阅读该 pdf 时，小书匠会自动将该 pdf 下载下来。



## 步骤


### 使用图片语法或者附件语法

使用附件语法（需要到`设置>语法扩展>附件`选项打开/或者使用元数据 `grammar_attachment:true`）,或者图片语法，再用网络链接指向具体的 pdf 地址。

注: 这里建议使用附件语法进行显示，如果使用了图片语法，系统会第一时间将该链接做为图片进行下载，等下载完了，再判断该文件是否真正的图片还是 pdf 文件，如果该 pdf 文件特别大，就很容易卡住.


![](./images/1677588096279.png)

### 在小书匠立时预览里，点击该附件，会提示下载操作


![](./images/1677588136823.png)

### 下载完成后，就可以进行批注，高亮等操作了



![](./images/1677588248578.png)



## 示例

=[latex](https://raw.githubusercontent.com/suziwen/pdffiles/main/LaTeX-cn-v1.6.4pre.pdf)



> 
> ![LaTeX-cn](./images/06ca6064adde4e75966a27d81b52c2ea.png)
> 
> [LaTeX-cn - P27](xsjapp://pdf/8a05a2b7-7c9d-4915-8c59-d8a672dd1e0a__attachments/2386cb4bee92d0788f98f780876ac613.6.4pre.pdf#06ca6064adde4e75966a27d81b52c2ea)
> 

好像很简单的样子啊!!!!




> 
> 3.9.1 浮动体
> 浮动体将图或表与其标题定义为整体，然后动态排版，以解决图、表卡在换
> 页处造成的过长的垂直空白的问题．但有时它也会打乱你的排版意图，因此使用
> 与否需要根据情况决定．
> 图片的浮动体是figure环境，而表格的浮动体是table环境．一个典型的浮
> 动体例子：
> 
> [LaTeX-cn - P31](xsjapp://pdf/8a05a2b7-7c9d-4915-8c59-d8a672dd1e0a__attachments/2386cb4bee92d0788f98f780876ac613.6.4pre.pdf#13bc73468db54612afef27045d6c048a)
> 

这个看起来有点难。


## 注

1. 提供的 pdf 链接需要应用能够直接访问得到。
2. 注意网络链接地址的跨域访问限制。

