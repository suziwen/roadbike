---
title: PDF 阅读，批注，引用使用
tags: 文档,小书匠,pdf,批注,引用
createDate: 2023-01-07
cover: '![#center 40.57208237986269%](./images/randomCover.jpg)'
slug: 'pdf/pdfviewer_highlights_reference'
---


[toc!]

小书匠从 `8.11.9` 版本开始，提供 PDF 阅读，批注等功能。用户可以直接在小书匠内阅读 PDF 文档，并进行文字高亮，引用等操作。


## 阅读 PDF 入口

1. 新建一篇文章，将想要阅读的 PDF 文件拖拽到文章内。

![](./images/1673079438141.png)
2. 点击 PDF 附件，在弹出的浮动窗口里，进行 PDF 阅读，批注。

![](./images/1673079673393.png)
## 管理批注

### 创建批注


![](./images/1673080032206.png)

### 批注列表

![](./images/1673080246294.png)

## 批注引用

1. 将批注添加到笔记里

![](./images/1673080613141.png)

2. 批注引用

![](./images/1673080963205.png)