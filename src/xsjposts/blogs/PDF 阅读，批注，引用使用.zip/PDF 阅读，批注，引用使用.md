---
title: PDF 阅读，批注，引用使用
tags: 文档,小书匠,pdf,批注,引用
createDate: 2023-01-07
cover: '![#center 40.57208237986269%](./images/randomCover.jpg)'
slug: 'pdf/pdfviewer_highlights_reference'
---


[toc!]

小书匠从 `8.11.9` 版本开始，提供 PDF 阅读，批注等功能。用户可以直接在小书匠内阅读 PDF 文档，并进行文字高亮，引用等操作。


## 阅读 PDF 入口

1. 新建一篇文章，将想要阅读的 PDF 文件拖拽到文章内。

![](./images/1673079438141.png)
2. 点击 PDF 附件，在弹出的浮动窗口里，进行 PDF 阅读，批注。

![](./images/1673079673393.png)
## 管理批注

### 创建批注


![](./images/1673080032206.png)

### 批注列表

![](./images/1673080246294.png)

## 批注引用

1. 将批注添加到笔记里

![](./images/1673080613141.png)

2. 批注引用

![](./images/1673080963205.png)


## 快捷键

### Navigation

The <kbd>Home</kbd>, <kbd>End</kbd>, <kbd>Page up</kbd>, <kbd>Page down</kbd> and all arrow keys can be used to navigate the document. Moreover, the following navigation shortcuts exist:

*   **Next page:** <kbd>n</kbd>, <kbd>j</kbd>, <kbd>Space bar</kbd> (presentation mode only), <kbd>Enter</kbd> (presentation mode only) or left click (presentation mode only)
*   **Previous page:** <kbd>p</kbd>, <kbd>k</kbd>, <kbd>Shift</kbd> + <kbd>Space bar</kbd> (presentation mode only), <kbd>Shift</kbd> + <kbd>Enter</kbd> (presentation mode only) or <kbd>Shift</kbd> + left click (presentation mode only)

### Viewer controls

User interface buttons or <kbd>ctrl</kbd> + mouse wheel can be used to change the zooming level, but keyboard shortcuts are also available:

*   **放大:** <kbd>ctrl</kbd> + <kbd>+</kbd>, <kbd>ctrl</kbd> + <kbd>=</kbd>
*   **缩小:** <kbd>ctrl</kbd> + <kbd>-</kbd>
*   **恢复默认大小:** <kbd>ctrl</kbd> + <kbd>0</kbd>
*   **顺时针旋转:** <kbd>r</kbd>
*   **逆时针旋转:** <kbd>shift</kbd> + <kbd>r</kbd>
*   **演示模式:** <kbd>ctrl</kbd> + <kbd>alt</kbd> + <kbd>p</kbd> (does not work in IE11)
*   **Enable the hand tool:** <kbd>h</kbd>
*   **Enable the text selection tool:** <kbd>s</kbd>
*   **Move focus to the 'go to page' box:** <kbd>ctrl</kbd> + <kbd>alt</kbd> + <kbd>g</kbd>
*   **查找:** <kbd>ctrl</kbd> + <kbd>f</kbd>
*   **Find next occurrence of text in the document:** <kbd>ctrl</kbd> + <kbd>g</kbd>
*   **Find previous occurrence of text in the document:** <kbd>shift</kbd> + <kbd>ctrl</kbd> + <kbd>g</kbd>
*   **Download the document:** <kbd>ctrl</kbd> + <kbd>s</kbd>
*   **Print the document:** <kbd>ctrl</kbd> + <kbd>p</kbd>

(replace ctrl with meta on some configurations)

### Outline sidebar

*   Use F4 to toggle the visibility of the sidebar.
*   After showing the sidebar, click on the "Show document outline" button to show the document outline (if the PDF file has one).
*   Nested outline items can be expanded/collapsed by clicking on the triangles at the left of an item.
*   To expand/collapse all items under the selected item, press <kbd>Shift</kbd> while clicking on the triangle.
*   Double-click on the "Show document outline" button to expand/collapse all outline items.